import pickle
import numpy as np

model = pickle.load(open("models/lr.pkl", "rb"))
def test(data):
    x = np.expand_dims(data, axis=0)
    pred = model.predict(x)
    return pred


predictions = test([30,40,0,25])
print(f"Default Payment for next month is : ",predictions[0])