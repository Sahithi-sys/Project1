import pickle
import numpy as np

model = pickle.load(open("models/lr.pkl", "rb"))
def test(data):
    values = data
    pay = np.std(values[1:7])
    due = []
    for i in range(0,6):
        due.extend([(values[7+i] - values[13+i]) // values[0]])
    x = np.array([np.std(due), pay])
    x = np.expand_dims(x, axis=0)
    pred = model.predict(x)
    return pred


predictions = test([30000,2,0,1,-1,2,0,20000,0,600,400,8000,5000,0,0,5000,0,10000,0])
print(f"Default Payment for next month is : ",predictions[0])